import React from 'react';
import { Camera, Video, Mic, Phone, Radio, Navigation } from 'lucide-react';

export default function ChatFooter({ onSendMedia, onStartCall, onStartLive, onSendLocation }) {
  return (
    <div className="p-3 flex items-center gap-4 bg-white border-t">
      <label className="cursor-pointer">
        <Camera size={22} />
        <input type="file" accept="image/*" hidden onChange={onSendMedia} />
      </label>

      <label className="cursor-pointer">
        <Video size={22} />
        <input type="file" accept="video/*" hidden onChange={onSendMedia} />
      </label>

      <button onClick={() => alert('Grabando audio (demo)')} title="Audio">
        <Mic size={22} />
      </button>

      <button onClick={onStartCall} title="Llamada">
        <Phone size={22} />
      </button>

      <button onClick={onStartLive} title="Live">
        <Radio size={22} />
      </button>

      <button onClick={onSendLocation} title="Ir al local">
        <Navigation size={22} />
      </button>
    </div>
  );
}
