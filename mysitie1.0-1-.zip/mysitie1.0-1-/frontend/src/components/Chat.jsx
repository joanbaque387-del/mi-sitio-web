import React, { useEffect, useState, useRef } from 'react';
import ChatFooter from './ChatFooter';
import { fetchMessages, sendMessage as apiSendMessage, sendLocation as apiSendLocation } from '../services/chat';

export default function Chat({ businessLocation, apiBase }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const ref = useRef();

  useEffect(() => {
    fetchMessages().then(setMessages).catch(console.error);
  }, []);

  useEffect(() => {
    if (ref.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [messages]);

  async function handleSend(e) {
    e.preventDefault();
    if (!text.trim()) return;
    const msg = await apiSendMessage({ text });
    setMessages(prev => [...prev, msg]);
    setText('');
  }

  async function handleSendMedia(ev) {
    const file = ev.target.files?.[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('media', file);
    fd.append('text', '');
    const res = await fetch((apiBase || 'http://localhost:4000') + '/api/messages/media', {
      method: 'POST',
      body: fd
    });
    const data = await res.json();
    setMessages(prev => [...prev, data]);
  }

  async function handleStartCall(){ alert('Funcionalidad de llamada iniciada (demo)'); }
  async function handleStartLive(){ alert('Iniciando live (demo)'); }

  async function handleSendLocation(){ 
    if (!businessLocation) {
      navigator.geolocation.getCurrentPosition(async pos => {
        const lat = pos.coords.latitude, lng = pos.coords.longitude;
        const msg = await apiSendLocation({ lat, lng });
        setMessages(prev => [...prev, msg]);
      }, err => alert('No se pudo obtener ubicación: ' + err.message));
      return;
    }
    const msg = await apiSendLocation({ lat: businessLocation.lat, lng: businessLocation.lng });
    setMessages(prev => [...prev, msg]);
  }

  return (
    <div className="w-full max-w-2xl mx-auto bg-white rounded-lg shadow-md overflow-hidden flex flex-col" style={{height: '600px'}}>
      <div className="p-4 border-b font-semibold">Chat</div>
      <div ref={ref} className="flex-1 p-4 overflow-y-auto space-y-3 bg-gray-50">
        {messages.map((m, i) => (
          <div key={i} className="p-3 bg-white rounded shadow-sm">
            <div className="text-xs text-gray-400">{m.sender || 'Usuario'}</div>
            {m.type === 'location' ? (
              <div>
                <div className="text-sm text-blue-600">Ubicación: {m.lat}, {m.lng}</div>
                <a className="text-xs text-indigo-600" href={`https://www.google.com/maps/dir/?api=1&destination=${m.lat},${m.lng}`} target="_blank" rel="noreferrer">Abrir ruta en Google Maps</a>
              </div>
            ) : m.media_url ? (
              m.media_type && m.media_type.startsWith('video') ? (
                <video src={m.media_url} controls className="w-full h-48 object-cover" />
              ) : (
                <img src={m.media_url} alt="media" className="w-full h-48 object-cover" />
              )
            ) : (
              <div className="text-sm">{m.text}</div>
            )}
          </div>
        ))}
      </div>

      <ChatFooter 
        onSendMedia={handleSendMedia} 
        onStartCall={handleStartCall} 
        onStartLive={handleStartLive} 
        onSendLocation={handleSendLocation}
        businessLocation={businessLocation}
      />

      <form onSubmit={handleSend} className="p-3 border-t flex gap-2">
        <input value={text} onChange={e=>setText(e.target.value)} placeholder="Escribe un mensaje..." className="flex-1 p-2 border rounded" />
        <button className="px-4 py-2 bg-blue-600 text-white rounded">Enviar</button>
      </form>
    </div>
  );
}
