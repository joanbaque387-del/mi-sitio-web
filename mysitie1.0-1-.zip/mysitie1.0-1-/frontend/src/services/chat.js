const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

export async function fetchMessages() {
  const res = await fetch(API_BASE + '/messages');
  if (!res.ok) throw new Error('Failed to fetch messages');
  return res.json();
}

export async function sendMessage({ text }) {
  const res = await fetch(API_BASE + '/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  return res.json();
}

export async function sendLocation({ lat, lng }) {
  const res = await fetch(API_BASE + '/messages/location', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ lat, lng })
  });
  return res.json();
}
