const express = require('express');
const router = express.Router();
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

let messages = [];

router.get('/', (req, res) => { res.json(messages); });

router.post('/', (req, res) => {
  const { text } = req.body || {};
  const msg = { sender: 'Usuario', text, created_at: new Date() };
  messages.push(msg);
  res.json(msg);
});

router.post('/media', upload.single('media'), (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file' });
  const url = `/uploads/${req.file.filename}`;
  const msg = { sender: 'Usuario', media_url: url, media_type: req.file.mimetype, created_at: new Date() };
  messages.push(msg);
  res.json(msg);
});

router.post('/location', (req, res) => {
  const { lat, lng } = req.body || {};
  const msg = { sender: 'Usuario', type: 'location', lat, lng, created_at: new Date() };
  messages.push(msg);
  res.json(msg);
});

module.exports = router;
